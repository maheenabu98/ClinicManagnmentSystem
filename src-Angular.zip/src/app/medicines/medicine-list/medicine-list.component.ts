import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medicine-list',
  templateUrl: './medicine-list.component.html',
  styleUrls: ['./medicine-list.component.scss']
})
export class MedicineListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
