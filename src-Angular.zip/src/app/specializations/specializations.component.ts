import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-specializations',
  templateUrl: './specializations.component.html',
  styleUrls: ['./specializations.component.scss']
})
export class SpecializationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
