export class User {
    
    userId:number=0;
	 userName:string='';
	 mobileNo:string='';
	 address:string='';
	 email:string='';
	 password:string='';
	 isActive:string='';
	
	 roleId:number=0;
}
