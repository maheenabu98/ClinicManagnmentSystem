import { Injectable } from '@angular/core';
import {HttpClient}from'@angular/common/http';
import {User} from './user'
import { Observable } from 'rxjs';
import {environment}from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})


export class UsersService {
  formData:User=new User();
  constructor(private httpClient: HttpClient) { }

  getUser(userId:number):Observable<any>{

    return this.httpClient.get(environment.apiUrl+"/api/users/"+userId)

   }

}
