import { Test } from './test';

describe('Test', () => {
  it('should create an instance', () => {
    expect(new Test()).toBeTruthy();
  });
});
