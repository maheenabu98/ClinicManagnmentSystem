import { Injectable } from '@angular/core';
import {HttpClient}from'@angular/common/http';
import {environment}from 'src/environments/environment';
import { Observable } from 'rxjs';
import{Prescription} from 'src/app/shared/prescription'
import { Appoinment } from './appoinment';

import { Medicine } from './medicine';
@Injectable({
  providedIn: 'root'
})
export class PrescriptionService {

  //create an instance
  formData :Prescription=new Prescription();
  prescription:Prescription[];
  medicines:Medicine[];
  constructor(private httpClient: HttpClient) { }
  
  addPrescription(appoinment:Appoinment):Observable<any>{
    return this.httpClient.post(environment.apiUrl+"/prescriptions",appoinment);
  }

  getMedicinesDropdown():Observable<any>{

    return this.httpClient.get<Medicine>(environment.apiUrl+"/api/medicines");
          
       

  }

 getPrescription(){
  this.httpClient.get(environment.apiUrl+"/api/prescriptions/").toPromise().then(response=>
    this.prescription=response as Prescription[]);
 }
}
