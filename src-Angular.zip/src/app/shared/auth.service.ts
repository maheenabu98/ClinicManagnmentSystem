import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router, ROUTER_CONFIGURATION } from "@angular/router";
import { environment } from "src/environments/environment";
import { User } from "./user";

@Injectable({
    providedIn:'root'
})

export class AuthService {
    constructor(private httpClient :HttpClient,private router:Router){}
                //verify login

                public loginVerify(user:User){
                    console.log(user.userName);
                    console.log(user.password);
                    console.log("we are in login verify")
                    //calling 
                    return this.httpClient.get<User>(environment.apiUrl+"/api/users/namepassword/"+user.userName+"&"+user.password);
                }
//LogoUt
public logOut(){

    sessionStorage.removeItem('userId');
    localStorage.removeItem('userId');
    localStorage.removeItem('ACcESS_ROLE');
}
    
}