export class Role {

    roleId:number=0;
   roleName:string='';
}
