import{User} from 'src/app/shared/user'
import{Specialization } from 'src/app/shared/specialization'
export class Doctor {

      doctorId:number=0;
	  userId:number=0;
	 double:  number=0;
	 specialisationId:number=0;
       userName:string='';
       specialisationName:string='';

       

      private user:User;

      private specialisation :Specialization ;

      

      
       
}
