import { Prescription } from './prescription';

describe('Prescription', () => {
  it('should create an instance', () => {
    expect(new Prescription()).toBeTruthy();
  });
});
