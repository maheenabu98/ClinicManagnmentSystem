export class PrescribedMedicine {
}
