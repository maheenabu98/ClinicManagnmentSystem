import { Injectable } from '@angular/core';
import {HttpClient}from'@angular/common/http';
import { Appoinment } from './appoinment';
import {environment}from 'src/environments/environment';
import { Doctor } from './doctor';

@Injectable({
  providedIn: 'root'
})
export class AppoinmentService {

  formData: Appoinment=new Appoinment();
  appoinments:Appoinment[];
  docters:Doctor[];
  docter:Doctor;
  userId:string;
  docId:number;
  constructor(private httpClient:HttpClient) { }

  //get all appoinments
  getAllAppoinment(){

  
      
    this.httpClient.get(environment.apiUrl+"/api/appoinment").toPromise().then(respose=>this.appoinments=respose as Appoinment[]);
  }

  getDoctor(){
    
  }
  //get a particular appoinment
  getAppoinment(docter:Doctor){
    
    this.httpClient.get(environment.apiUrl+"/api/appoinment"+docter.doctorId).toPromise().then(respose=>this.appoinments=respose as Appoinment[]);
  }

}
