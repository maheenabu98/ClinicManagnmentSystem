export class Specialization {

    specialisationId: number=0;
    specialisationName:string='';
}
