import { PatientComponent } from "../patients/patient/patient.component";
import { Doctor } from "./doctor";
import { User } from "./user";
import{Patient} from "./patient"
export class Appoinment {


    appoinmentId:number=0;
        patientId:number=0;
        doctorId:number=0;
        receptionistId:number=0;
        date:Date= new Date("yyyy-MM-dd");
        tokenNo:number=0;
        status:string='';

        doctor:Doctor;
        user:User;
        patient:Patient;

     
}
