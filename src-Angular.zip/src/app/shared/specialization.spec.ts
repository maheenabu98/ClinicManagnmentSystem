import { Specialization } from './specialization';

describe('Specialization', () => {
  it('should create an instance', () => {
    expect(new Specialization()).toBeTruthy();
  });
});
