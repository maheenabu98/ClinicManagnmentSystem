export class Medicine {

    medicineId:number=0;
    medicineName: string;
    medicinePrice:number=0;
}
