import { Injectable } from '@angular/core';
import {HttpClient}from'@angular/common/http';
import { environment } from 'src/environments/environment';
import { Medicine } from './medicine';
@Injectable({
  providedIn: 'root'
})
export class MedicineService {

  formData:Medicine=new Medicine();
  medicines:Medicine[];
  constructor(private httpClient: HttpClient) { }


  getAllMedicines(){
    this.httpClient.get(environment.apiUrl+"/api/medicines").toPromise().then(response=>
      this.medicines=response as Medicine[]
        );
  }

}
