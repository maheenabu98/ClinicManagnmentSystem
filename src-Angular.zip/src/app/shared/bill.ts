export class Bill {
}
