import { PrescribedMedicine  } from "src/app/shared/prescribed-medicine";
import {Appoinment} from "src/app/shared/appoinment"

export class Prescription {

     prescriptionId:number;
	//private Integer medicineId;
	 prescriptionNote:string;
	//private Integer doctorId;
	
	 prescribedMedID:number;
	 appoinmentId:number;

     pmedicine:PrescribedMedicine;

     appoinments:Appoinment;

     
    
}
