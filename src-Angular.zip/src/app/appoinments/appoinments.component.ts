import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appoinments',
  templateUrl: './appoinments.component.html',
  styleUrls: ['./appoinments.component.scss']
})
export class AppoinmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
