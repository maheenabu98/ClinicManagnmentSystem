import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Appoinment } from 'src/app/shared/appoinment';
import{AppoinmentService} from 'src/app/shared/appoinment.service';
import { Doctor } from 'src/app/shared/doctor';
import{DoctorService} from 'src/app/shared/doctor.service';
@Component({
  selector: 'app-appoinment-list',
  templateUrl: './appoinment-list.component.html',
  styleUrls: ['./appoinment-list.component.scss']
})
export class AppoinmentListComponent implements OnInit {

  constructor(public appoinmentService:AppoinmentService,private router: Router) { }

  ngOnInit(): void {//life cycle hook

    this.appoinmentService.getAllAppoinment();
    

  }

  
  

  populateForm(apnmt:Appoinment){
    console.log(apnmt);
    this.appoinmentService.formData=Object.assign({},apnmt);
  }

  gotoPatientHistory(apnmt:Appoinment){
    console.log(apnmt)

   this.router.navigate(['/prescriptions']);
  }
  getPrescription(appoinmentId:number){
    console.log("we are here");
    
    this.router.navigate(['/prescription']);
   

  }

  deleteAppoinment(appoinmentId:number){
    console.log(appoinmentId);
  }

}
