import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill',
  templateUrl: './bills.component.html',
  styleUrls: ['./bills.component.scss']
})
export class BillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
