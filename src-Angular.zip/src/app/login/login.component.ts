import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import{User} from 'src/app/shared/user';
import{AuthService} from'../shared/auth.service';
import { DoctorService } from '../shared/doctor.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  //declare for a variable for FormGroup

  loginForm:FormGroup;


  //devclare a varible for submit

  isSubmitted:boolean=false;

  //Declare a variable for erro
  
  error:any='';

  //Create a variable for user
  
  loginUser:User;
  userId:number;
  userType:string;
  //Di
  constructor (private formBuilder:FormBuilder,
               private authService:AuthService,
               private docterService:DoctorService,
               private router:Router) { }

  ngOnInit(): void {

    //create reactive form

    //userName,password
    this.loginForm=this.formBuilder.group(
      
      //userName
      //FormControlName Fields
      {
        userName:['',[Validators.required]],
        password:['',[Validators.required]]
      }
      //Password
    );

  }
  //get control method

  get formControls(){
    return this.loginForm.controls;
  }

  //Login Verify method
  loginCredentials(){
    this.isSubmitted=true;

    //Form is valid
    if(this.loginForm.valid){
      //calling method form  webservice
      this.authService.loginVerify(this.loginForm.value).subscribe(

        data=>{
          console.log(data);
          this.userId=data.userId;
          localStorage.setItem('userId',data.userId.toString());
          localStorage.setItem('userName',data.userName);
            sessionStorage.setItem('userName',data.userName);
            localStorage.setItem('ACCESS_ROLE',data.roleId.toString());
          //Form-Level Role-based authentication
          //chechking rolebased authorization
          

            this.router.navigateByUrl('/doctordashboard')

          
      
        },
        error=>{
          this.error="Invalid UserName or password"
        }
      );

    }else{
      this.error="Sorry...This is role is  not allowed here "
    }
    //form is invalid
  }

}