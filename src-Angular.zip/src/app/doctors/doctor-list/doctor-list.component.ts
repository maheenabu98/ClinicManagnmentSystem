import { Component, OnInit } from '@angular/core';
import{DoctorService} from 'src/app/shared/doctor.service'
import{Doctor} from 'src/app/shared/doctor'
@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.scss']
})
export class DoctorListComponent implements OnInit {

  constructor(public doctorService:DoctorService) { }

  ngOnInit(): void {//life cycle hook
      this.doctorService.getAllDoctors();
  }

  populateForm(doc:Doctor){
    console.log(doc);
    this.doctorService.formData=Object.assign({},doc)
  }
}
