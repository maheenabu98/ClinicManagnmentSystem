import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prescribed-medicines',
  templateUrl: './prescribed-medicines.component.html',
  styleUrls: ['./prescribed-medicines.component.scss']
})
export class PrescribedMedicinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
