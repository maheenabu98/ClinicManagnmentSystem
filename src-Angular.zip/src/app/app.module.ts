import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule}from'@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RolesComponent } from './roles/roles.component';
import { RoleComponent } from './Roles/role/role.component';
import { RoleListComponent } from './Roles/role-list/role-list.component';
import { UsersComponent } from './users/users.component';
import { SpecializationsComponent } from './specializations/specializations.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { MedicinesComponent } from './medicines/medicines.component';
import { PrescriptionsComponent } from './prescriptions/prescriptions.component';
import { PrescribedMedicinesComponent } from './prescribed-medicines/prescribed-medicines.component';
import { PrescribedMedicineComponent } from './prescribed-medicine/prescribed-medicine.component';
import { AppoinmentsComponent } from './appoinments/appoinments.component';
import { TestsComponent } from './tests/tests.component';
import { TestResultsComponent } from './test-results/test-results.component';
import { PatientsComponent } from './patients/patients.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BillComponent } from './bills/bills.component';
import { DoctorComponent } from './doctors/doctor/doctor.component';
import { DoctorListComponent } from './doctors/doctor-list/doctor-list.component';
import { DoctorDashboardComponent } from './doctors/doctor-dashboard/doctor-dashboard.component';
import { LoginComponent } from './login/login.component';
import { AppoinmentListComponent } from './appoinments/appoinment-list/appoinment-list.component';
import { PatientComponent } from './patients/patient/patient.component';
import { PatientListComponent } from './patients/patient-list/patient-list.component';
import { MedicineComponent } from './medicines/medicine/medicine.component';
import { MedicineListComponent } from './medicines/medicine-list/medicine-list.component';

import { PrescriptionComponent } from './prescriptions/prescription/prescription.component';

@NgModule({
  declarations: [
    AppComponent,
    RolesComponent,
    RoleComponent,
    RoleListComponent,
    UsersComponent,
    SpecializationsComponent,
    DoctorsComponent,
    MedicinesComponent,
    PrescriptionsComponent,
    PrescribedMedicinesComponent,
    PrescribedMedicineComponent,
    AppoinmentsComponent,
    TestsComponent,
    TestResultsComponent,
    PatientsComponent,
    BillComponent,
    DoctorComponent,
    DoctorListComponent,
    DoctorDashboardComponent,
    LoginComponent,
    AppoinmentListComponent,
    PatientComponent,
    PatientListComponent,
    MedicineComponent,
    MedicineListComponent,
    
    PrescriptionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
