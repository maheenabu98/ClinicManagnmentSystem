import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import{PrescriptionService} from 'src/app/shared/prescription.service'
@Component({
  selector: 'app-prescription',
  templateUrl: './prescription.component.html',
  styleUrls: ['./prescription.component.scss']
})
export class PrescriptionComponent implements OnInit {

  constructor(public prescriptionService:PrescriptionService) { }
  public listMedicines:Array<String>=[];
  ngOnInit(): void {

  }
 //on submit even
  onSubmit(form:NgForm){
    //display values in console
    console.log(form.value)
    let addId=this.prescriptionService.formData.prescriptionId;
  }

  dropDownMedicinePrescription(){
    this.prescriptionService.getMedicinesDropdown().subscribe(data=>{
      data.forEach(element => {
        this.listMedicines.push(element["medicineId"]);
      });
    })
  }

}
