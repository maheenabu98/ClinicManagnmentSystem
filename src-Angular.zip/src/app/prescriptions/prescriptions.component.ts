import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import{PrescriptionService} from 'src/app/shared/prescription.service'
@Component({
  selector: 'app-prescriptions',
  templateUrl: './prescriptions.component.html',
  styleUrls: ['./prescriptions.component.scss']
})
export class PrescriptionsComponent implements OnInit {

  constructor(public prescriptionService:PrescriptionService) { }

  ngOnInit(): void {

this.prescriptionService.getPrescription();    

  }
 
}
