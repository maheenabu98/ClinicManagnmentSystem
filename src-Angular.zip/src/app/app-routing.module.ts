import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{LoginComponent} from 'src/app/login/login.component'
import{DoctorsComponent} from './doctors/doctors.component'
import { DoctorComponent } from './doctors/doctor/doctor.component';
import { DoctorListComponent } from './doctors/doctor-list/doctor-list.component';
import { AppoinmentsComponent } from './appoinments/appoinments.component';
import { AppoinmentListComponent } from './appoinments/appoinment-list/appoinment-list.component';
import { PatientsComponent } from './patients/patients.component';
import{PatientListComponent} from './patients/patient-list/patient-list.component';
import{PatientComponent} from './patients/patient/patient.component'
import{MedicinesComponent} from './medicines/medicines.component';
import{MedicineComponent} from './medicines/medicine/medicine.component';
import{MedicineListComponent} from './medicines/medicine-list/medicine-list.component';
import { DoctorDashboardComponent } from './doctors/doctor-dashboard/doctor-dashboard.component';
import { PrescriptionComponent } from './prescriptions/prescription/prescription.component';
import { PrescriptionsComponent } from './prescriptions/prescriptions.component';


const routes: Routes = [
  {path:'',redirectTo:'/login',pathMatch:'full'},
  {path:'login',component:LoginComponent},
  {path:'doctor',component:DoctorComponent},
  {path:'appoinments',component:AppoinmentsComponent},
  {path:'doctorlist',component:DoctorListComponent},
  {path:'doctors',component:DoctorsComponent},
  {path:'appoinmentlist',component:AppoinmentListComponent},
  {path:'patient',component:PatientComponent},
  {path:'patients',component:PatientsComponent},
  {path:'patientlist',component:PatientListComponent},
  {path:'medicine',component:MedicineComponent},
  {path:'medicines',component:MedicinesComponent},
  {path:'medicinelist',component:MedicineListComponent},
  {path:'doctordashboard',component:DoctorDashboardComponent},
  {path:'prescription',component:PrescriptionComponent},
  {path:'prescriptions',component:PrescriptionsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
