package com.faith.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.faith.app.dto.AppoinmentDto;
import com.faith.app.model.Appoinment;

import com.faith.app.service.IAppoinmentService;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class AppoinmentController {
	
	@Autowired
	private IAppoinmentService appoinmentService;
	
	@GetMapping("/appoinment")
	public ResponseEntity<List<Appoinment>> ListAllAppoinments(){
		return new ResponseEntity<List<Appoinment>>(appoinmentService.getAllAppoinment(),HttpStatus.OK);
	}
	
	@GetMapping("/appoinment/{appoinmentId}")
	public Optional<Appoinment>getByAppoinmentById(@PathVariable Integer id){
		return appoinmentService.getAppoinmentById(id);
	}
	
	@GetMapping("/appoinment/{doctorId}")
	public ResponseEntity<List<Appoinment>>ListAllAppoinmentsByDoctorId(@PathVariable Integer doctorId){
		
		return new ResponseEntity<List<Appoinment>>(appoinmentService.getAllAppoinmentsBydocterId(doctorId),HttpStatus.OK);
	}
	
	
	@PostMapping("/appoinment")
	public void addAppoinment(@RequestBody Appoinment appoinment) {
		appoinmentService.addAppoinment(appoinment);
	}
	
	@PutMapping("/appoinment")
	public void updateAppoinment(@RequestBody Appoinment appoinment) {
		appoinmentService.updateAppoinment(appoinment);
	}
	
	@DeleteMapping("/appoinment/{appoinmentId}")
	public void deleteAppoinment(@PathVariable Integer appoinmentId){
		appoinmentService.deleteAppoinment(appoinmentId);
		
	}
	
	
}
