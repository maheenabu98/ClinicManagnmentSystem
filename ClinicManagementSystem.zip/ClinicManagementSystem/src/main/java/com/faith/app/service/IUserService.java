package com.faith.app.service;

import java.util.List;
import java.util.Optional;

import com.faith.app.dto.UserDto;
import com.faith.app.model.User;

public interface IUserService {
 
	//list all
		public List<User>getAllUsers();
		
		//get user by id
		public Optional<User>getUserById(Integer userId);
		
		public User getUserByuserNamepassword(String userName,String password);
		
		//insert
		public void addUser(User user);
		
		//update
		public void updateUser(User user);
		
		//delete
		public void deleteUser(Integer userId);
		
}
