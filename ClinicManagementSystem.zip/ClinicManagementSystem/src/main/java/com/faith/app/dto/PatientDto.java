package com.faith.app.dto;

public class PatientDto {

	private Integer patientId;
	private String patientName;
	private String phone;
	private String address;
	private String email;
	private String bloodGroup;
	private Integer age;
	
	
	public PatientDto() {
	
	}


	public PatientDto(Integer patientId, String patientName, String phone, String address, String email,
			String bloodGroup, Integer age) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.phone = phone;
		this.address = address;
		this.email = email;
		this.bloodGroup = bloodGroup;
		this.age = age;
	}


	public Integer getPatientId() {
		return patientId;
	}


	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}


	public String getPatientName() {
		return patientName;
	}


	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getBloodGroup() {
		return bloodGroup;
	}


	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}


	public Integer getAge() {
		return age;
	}


	public void setAge(Integer age) {
		this.age = age;
	}
	
	
	
}
