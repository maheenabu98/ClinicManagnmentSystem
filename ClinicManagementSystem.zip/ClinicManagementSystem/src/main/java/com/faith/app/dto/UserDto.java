package com.faith.app.dto;

public class UserDto {
	
	private Integer userId;
	private String userName;
	private String mobileNo;
	private String address;
	private String email;
	private String password;
	private int roleId;
	private String roleName;
	private String isActive;
	
	
	public UserDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	public UserDto(Integer userId, String userName, String mobileNo, String address, String email, String password,
			int roleId, String isActive) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.mobileNo = mobileNo;
		this.address = address;
		this.email = email;
		this.password = password;
		this.roleId = roleId;
		this.isActive = isActive;
	}


	public UserDto(Integer userId, String userName, String mobileNo, String address, String email, String password,
			String roleName, String isActive) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.mobileNo = mobileNo;
		this.address = address;
		this.email = email;
		this.password = password;
		this.roleName = roleName;
		this.isActive = isActive;
	}


	public Integer getUserId() {
		return userId;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public int getRoleId() {
		return roleId;
	}


	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}


	public String getRoleName() {
		return roleName;
	}


	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}


	public String getIsActive() {
		return isActive;
	}


	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	
	
	
	

}
