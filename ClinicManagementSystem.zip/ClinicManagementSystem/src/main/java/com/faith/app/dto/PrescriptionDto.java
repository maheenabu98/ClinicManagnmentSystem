package com.faith.app.dto;

public class PrescriptionDto {
	
	private Integer prescriptionId;
	//private Integer medicineId;
	private String prescriptionNote;
	private Integer doctorId;
	private String doctorName;
	
	
	
	public PrescriptionDto() {
		super();
		// TODO Auto-generated constructor stub
	}



	public PrescriptionDto(Integer prescriptionId, String prescriptionNote, Integer doctorId) {
		super();
		this.prescriptionId = prescriptionId;
		this.prescriptionNote = prescriptionNote;
		this.doctorId = doctorId;
	}



	public PrescriptionDto(Integer prescriptionId, String prescriptionNote, String doctorName) {
		super();
		this.prescriptionId = prescriptionId;
		this.prescriptionNote = prescriptionNote;
		this.doctorName = doctorName;
	}



	public Integer getPrescriptionId() {
		return prescriptionId;
	}



	public void setPrescriptionId(Integer prescriptionId) {
		this.prescriptionId = prescriptionId;
	}



	public String getPrescriptionNote() {
		return prescriptionNote;
	}



	public void setPrescriptionNote(String prescriptionNote) {
		this.prescriptionNote = prescriptionNote;
	}



	public Integer getDoctorId() {
		return doctorId;
	}



	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}



	public String getDoctorName() {
		return doctorName;
	}



	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	
	
	

}
