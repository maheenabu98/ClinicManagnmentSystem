package com.faith.app.dto;

import java.util.Date;

public class BillDto {
	
	private Integer billId;
	private Integer prescriptionId;
	private String patientName;
//	private Integer testId;
	private Date billDate;
	private double totalAmount;

}
