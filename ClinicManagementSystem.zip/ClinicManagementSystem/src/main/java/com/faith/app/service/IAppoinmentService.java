package com.faith.app.service;

import java.util.List;
import java.util.Optional;

import com.faith.app.dto.AppoinmentDto;
import com.faith.app.model.Appoinment;


public interface IAppoinmentService {
	
	
	
	//Get All User
		public List<Appoinment>getAllAppoinment();
		//Get User By Id
		public Optional<Appoinment>getAppoinmentById(Integer id);
	    //Insert
		public void addAppoinment(Appoinment appoinment);
		
		//Update
		public void updateAppoinment(Appoinment appoinment);
		
		//Delete User
		public void deleteAppoinment(Integer appoinmentId);
		
		public  List<Appoinment>getAllAppoinmentsBydocterId(Integer doctorId);
		
		
}
