package com.faith.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.faith.app.dto.AppoinmentDto;
import com.faith.app.model.Appoinment;

import com.faith.app.repository.IAppoinmentRepository;
@Service
public class AppoinmentServiceImplementation implements IAppoinmentService {
	
	@Autowired
	public IAppoinmentRepository appoinmentRepository;
	
	@Override
	public List<Appoinment> getAllAppoinment() {
		
		return (List<Appoinment>)appoinmentRepository.findAll();
	}

	@Override
	public Optional<Appoinment> getAppoinmentById(Integer id) {
		
		return appoinmentRepository.findById(id);
	}

	@Override
	public void addAppoinment(Appoinment appoinment) {
	
		appoinmentRepository.save(appoinment);

	}

	@Override
	public void updateAppoinment(Appoinment appoinment) {
		
		appoinmentRepository.save(appoinment);
	}

	@Override
	public void deleteAppoinment(Integer appoinmentId) {
		appoinmentRepository.deleteById(appoinmentId);

	}

	@Override
	public List<Appoinment> getAllAppoinmentsBydocterId(Integer doctorId) {
		
		 return (List<Appoinment>)appoinmentRepository.getAppoinmentBydocterId(doctorId);
	}

}
