package com.faith.app.dto;

public class DoctorDto {

	private Integer doctorId;
	private Integer userId;
	private String doctorName;
	private double doctorFees;
	private Integer specialisationId;
	private String specialisationName;
	
	
	
	
	
	public DoctorDto() {
		
	}





	public DoctorDto(Integer doctorId, Integer userId, double doctorFees, Integer specialisationId) {
		super();
		this.doctorId = doctorId;
		this.userId = userId;
		this.doctorFees = doctorFees;
		this.specialisationId = specialisationId;
	}





	public DoctorDto(Integer doctorId, String doctorName, double doctorFees, String specialisationName) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorFees = doctorFees;
		this.specialisationName = specialisationName;
	}





	public Integer getDoctorId() {
		return doctorId;
	}





	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}





	public Integer getUserId() {
		return userId;
	}





	public void setUserId(Integer userId) {
		this.userId = userId;
	}





	public String getDoctorName() {
		return doctorName;
	}





	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}





	public double getDoctorFees() {
		return doctorFees;
	}





	public void setDoctorFees(double doctorFees) {
		this.doctorFees = doctorFees;
	}





	public Integer getSpecialisationId() {
		return specialisationId;
	}





	public void setSpecialisationId(Integer specialisationId) {
		this.specialisationId = specialisationId;
	}





	public String getSpecialisationName() {
		return specialisationName;
	}





	public void setSpecialisationName(String specialisationName) {
		this.specialisationName = specialisationName;
	}
	
	
	
	
	
}
