package com.faith.app.dto;

public class PrescribedMedicineDto {
	
	private Integer prescribedMedicineId;
	private Integer medicineID;
	
	
	
	

}
