package com.faith.app.dto;

public class MedicineDto {

	private Integer medicineId;
	private String medicineName;
	private double medicinePrice;
	
	private Integer prescribedMedicineId;
	private Integer prescriptionId;
	
	
	
	
	
	
	public MedicineDto(Integer medicineId, String medicineName, double medicinePrice) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.medicinePrice = medicinePrice;
	}






	public MedicineDto(Integer medicineId, String medicineName, double medicinePrice, Integer prescribedMedicineId,
			Integer prescriptionId) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.medicinePrice = medicinePrice;
		this.prescribedMedicineId = prescribedMedicineId;
		this.prescriptionId = prescriptionId;
	}






	public Integer getMedicineId() {
		return medicineId;
	}






	public void setMedicineId(Integer medicineId) {
		this.medicineId = medicineId;
	}






	public String getMedicineName() {
		return medicineName;
	}






	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}






	public double getMedicinePrice() {
		return medicinePrice;
	}






	public void setMedicinePrice(double medicinePrice) {
		this.medicinePrice = medicinePrice;
	}






	public Integer getPrescribedMedicineId() {
		return prescribedMedicineId;
	}






	public void setPrescribedMedicineId(Integer prescribedMedicineId) {
		this.prescribedMedicineId = prescribedMedicineId;
	}






	public Integer getPrescriptionId() {
		return prescriptionId;
	}






	public void setPrescriptionId(Integer prescriptionId) {
		this.prescriptionId = prescriptionId;
	}
	
	
	
	
}
