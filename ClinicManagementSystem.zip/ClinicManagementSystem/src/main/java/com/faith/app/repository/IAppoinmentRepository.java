package com.faith.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.faith.app.dto.AppoinmentDto;
import com.faith.app.model.Appoinment;
@Repository
public interface IAppoinmentRepository extends CrudRepository<Appoinment, Integer> {
	
	
	
	//public List<Appoinment>getByDate
	@Query("from Appoinment where doctorId=?1")
	public List<Appoinment>getAppoinmentBydocterId( Integer doctorId);
}
