package com.faith.app.dto;

import java.util.Date;

public class AppoinmentDto {
	
    private Integer appoinmentId;
	private Integer patientId;
	private Integer doctorId;
	private Integer receptionistId;
	private Date date;
	private Integer tokenNo;
	private String status;
	private String doctorName;
	private String patientName;
	private String recepetionistName;
	
	
	public AppoinmentDto(Integer appoinmentId, Integer patientId, Integer doctorId, Integer receptionistId, Date date,
			Integer tokenNo, String status) {
		super();
		this.appoinmentId = appoinmentId;
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.receptionistId = receptionistId;
		this.date = date;
		this.tokenNo = tokenNo;
		this.status = status;
	}


	public AppoinmentDto(Integer appoinmentId, Date date, Integer tokenNo, String status, String doctorName,
			String patientName, String recepetionistName) {
		super();
		this.appoinmentId = appoinmentId;
		this.date = date;
		this.tokenNo = tokenNo;
		this.status = status;
		this.doctorName = doctorName;
		this.patientName = patientName;
		this.recepetionistName = recepetionistName;
	}


	public Integer getAppoinmentId() {
		return appoinmentId;
	}


	public void setAppoinmentId(Integer appoinmentId) {
		this.appoinmentId = appoinmentId;
	}


	public Integer getPatientId() {
		return patientId;
	}


	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}


	public Integer getDoctorId() {
		return doctorId;
	}


	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}


	public Integer getReceptionistId() {
		return receptionistId;
	}


	public void setReceptionistId(Integer receptionistId) {
		this.receptionistId = receptionistId;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public Integer getTokenNo() {
		return tokenNo;
	}


	public void setTokenNo(Integer tokenNo) {
		this.tokenNo = tokenNo;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getDoctorName() {
		return doctorName;
	}


	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}


	public String getPatientName() {
		return patientName;
	}


	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}


	public String getRecepetionistName() {
		return recepetionistName;
	}


	public void setRecepetionistName(String recepetionistName) {
		this.recepetionistName = recepetionistName;
	}
	
	
	
	
	
	

}
